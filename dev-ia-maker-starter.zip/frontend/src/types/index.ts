export type Message = {
  id: string
  title: string
  body: string
  author?: string | null
  status: 'draft' | 'published' | 'archived'
  created_at: string
  updated_at: string
}
