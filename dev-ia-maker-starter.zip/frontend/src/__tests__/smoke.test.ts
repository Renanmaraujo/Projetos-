import { describe, it, expect } from 'vitest'

describe('Smoke', () => {
  it('renders test runner', () => {
    expect(1 + 1).toBe(2)
  })
})
